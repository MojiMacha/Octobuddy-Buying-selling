# Phone Sticker Store — คู่มือติดตั้ง (ภาษาไทย)

โปรเจกต์ร้านค้าออนไลน์ตัวอย่าง ประกอบด้วยหน้าร้าน ลูกค้า ระบบตะกร้า/สั่งซื้อ ระบบ Admin และ Cloud Functions สำหรับ PromptPay QR + Stripe Checkout

## สิ่งที่ต้องมี
- Google/Firebase account และ Node.js 20+
- Firebase CLI: `npm install -g firebase-tools`
- บัญชี Stripe สำหรับเปิดใช้ Payment Gateway (ต้องผ่านการยืนยันตัวตน/ธุรกิจตามข้อกำหนด Stripe)
- PromptPay ID ของร้านที่ลงทะเบียนรับเงินแล้ว

## 1) สร้าง Firebase
1. เข้า https://console.firebase.google.com/ แล้วสร้างโปรเจกต์
2. เพิ่ม Web App และคัดลอก Firebase config มาใส่ใน `firebase-config.js`
3. เปิด Authentication > Sign-in method > Email/Password
4. สร้าง Firestore Database และเปิด Storage
5. แก้ `.firebaserc` ให้เป็น Project ID ของคุณ
6. ตั้งค่า Firestore/Storage rules ก่อนเปิดให้ลูกค้าใช้

## 2) ตั้งค่าสิทธิ์ Admin
1. สมัครบัญชีผ่านหน้าร้านก่อน
2. Firebase Console > Authentication > Users คัดลอก UID ของบัญชีผู้ดูแล
3. สร้าง Service Account key ใน Project settings > Service accounts (เก็บไฟล์นี้เป็นความลับ ห้ามอัปโหลด GitHub)
4. ตั้ง environment variable `GOOGLE_APPLICATION_CREDENTIALS` ให้ชี้ไปยังไฟล์ Service Account
5. ติดตั้งแพ็กเกจในโฟลเดอร์โปรเจกต์: `npm install firebase-admin`
6. รัน `node scripts_set_admin.js YOUR_USER_UID`
7. ออกจากระบบแล้วเข้าสู่ระบบ Admin ใหม่เพื่อ refresh token

## 3) ตั้งค่า PromptPay QR
ตั้ง Secret ของ Functions ด้วย PromptPay ID (เบอร์โทรศัพท์หรือเลขประจำตัวที่ผูก PromptPay):
`firebase functions:secrets:set PROMPTPAY_ID`
จากนั้น deploy Functions ตามขั้นตอนด้านล่าง
**หมายเหตุ:** QR ที่สร้างเป็น QR สำหรับรับชำระเงินแบบ PromptPay ตามยอดคำสั่งซื้อ ไม่ได้ตรวจสอบยอดเงินจากธนาคารอัตโนมัติ ผู้ดูแลต้องตรวจสอบรายการเงินจริงจากแอปธนาคาร/statement แล้วกดยืนยันรับเงินใน Admin ห้ามยืนยันจากภาพสลิปเพียงอย่างเดียว

## 4) ตั้งค่า Payment Gateway (Stripe)
1. สมัคร/เปิดใช้งาน Stripe และตรวจสอบว่าบัญชีของคุณรองรับการรับชำระเงิน THB
2. ตั้ง Secret: `firebase functions:secrets:set STRIPE_SECRET` แล้วใส่ Secret Key จาก Stripe
3. ตั้งค่า Webhook ใน Stripe ให้เรียก URL ของ Firebase Function `stripeWebhook` (หลัง deploy) และเลือก event `checkout.session.completed`
4. ตั้ง Secret สำหรับ webhook signing secret: `firebase functions:secrets:set STRIPE_WEBHOOK_SECRET` แล้วใส่ Signing Secret จาก Stripe
5. ทดสอบด้วย Stripe test mode ก่อนเสมอ

## 5) ติดตั้งและ Deploy
```bash
firebase login
firebase use YOUR_PROJECT_ID
cd functions
npm install
cd ..
firebase deploy --only firestore:rules,storage,functions,hosting
```
ถ้าจะทดลองหน้าเว็บในเครื่อง ให้ใช้ Firebase Hosting emulator หรือ local server เช่น `npx serve .` (ต้องตั้ง Firebase config แล้ว)

## 6) เพิ่มสินค้า
1. เปิด `index.html` แล้วสมัครบัญชีลูกค้า
2. กำหนดบัญชีดังกล่าวเป็น Admin ตามข้อ 2
3. เปิด `admin.html` เข้าสู่ระบบ
4. กด “เพิ่มสินค้า” ใส่ชื่อ รายละเอียด หมวดหมู่ ราคา สต็อก และ URL รูปภาพ
5. สินค้าจะปรากฏในหน้าร้านเมื่อ Active

## โครงสร้าง
- `index.html` — หน้าร้าน/ลูกค้า/ตะกร้า/Checkout
- `admin.html` — Admin dashboard
- `app.js`, `admin.js` — การทำงานฝั่งเว็บ
- `firebase-config.js` — Firebase Web config (ไม่ใช่ secret แต่ควรตั้ง Security Rules)
- `functions/index.js` — PromptPay QR และ Stripe Checkout/Webhook
- `firestore.rules`, `storage.rules` — กฎความปลอดภัย

## ข้อจำกัดของเวอร์ชันเริ่มต้น (ควรทำก่อนเปิดขายจริง)
- PromptPay: Admin ต้องตรวจยอดเงินจริงและกดยืนยันเอง ยังไม่มี bank webhook/automatic reconciliation
- Stripe: ต้องตั้ง webhook secret ให้ถูกต้องและทดสอบการชำระเงินจริง/คืนเงิน
- สต็อก: เวอร์ชันนี้ยังไม่ reserve/deduct stock แบบ transaction เมื่อสั่งซื้อ ควรเพิ่มระบบจองสต็อก ป้องกันสั่งเกินจำนวน
- การยืนยัน PromptPay ใน Admin เป็นการทำงานด้วยมือ อย่าเปิดให้ลูกค้าแก้สถานะการชำระเงิน
- เพิ่ม rate limiting, validation ฝั่ง server, privacy policy, terms, shipping/returns และช่องทางติดต่อก่อนเปิดร้านจริง
- ใช้ HTTPS เท่านั้น และห้ามนำ Service Account หรือ Stripe Secret ไปไว้ในไฟล์ frontend/GitHub

นี่คือ starter project ที่ต่อยอดได้ ไม่ใช่ระบบรับประกันการชำระเงินจริงโดยไม่ตั้งค่าผู้ให้บริการและทดสอบก่อน

// รันจากเครื่องผู้พัฒนา: node scripts_set_admin.js USER_UID
// ต้องดาวน์โหลด Service Account JSON จาก Firebase Console และตั้ง GOOGLE_APPLICATION_CREDENTIALS
const admin=require("firebase-admin");
const uid=process.argv[2];
if(!uid){console.error("Usage: node scripts_set_admin.js USER_UID");process.exit(1)}
admin.initializeApp({credential:admin.credential.applicationDefault()});
admin.auth().setCustomUserClaims(uid,{admin:true}).then(()=>{console.log("กำหนดสิทธิ์ Admin แล้ว:",uid);process.exit(0)}).catch(e=>{console.error(e);process.exit(1)});